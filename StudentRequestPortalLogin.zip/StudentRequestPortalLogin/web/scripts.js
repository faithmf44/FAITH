document.getElementById('resetPasswordLink').addEventListener('click', function(event) {
    event.preventDefault();
    document.getElementById('resetPasswordPopup').style.display = 'block';
});

document.getElementById('resetPasswordForm').addEventListener('submit', function(event) {
    event.preventDefault();
    const email = document.getElementById('email').value;
    
    // Add your logic to handle the reset password here.
    // This could involve sending an AJAX request to a server-side endpoint.
    alert('Password reset link sent to ' + email);
    
    document.getElementById('resetPasswordPopup').style.display = 'none';
});



