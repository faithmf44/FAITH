import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.Cookie;
import javax.swing.JFrame;
import javax.swing.JOptionPane;


public class Login extends HttpServlet {

    /**
     *
     * @param request
     * @param response
     * @throws ServletException
     * @throws IOException
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
       try{
        
        response.setContentType("text/html");
          PrintWriter ck=response.getWriter();
        String username = request.getParameter("username");
        String password = request.getParameter("password");
         PrintWriter out = response.getWriter();
       
         

         if (username.equals("admin") && password.equals("admin123")) {
            HttpSession session = request.getSession();
            session.setAttribute("username", username);
            
            RequestDispatcher dispatcher = request.getRequestDispatcher("RequestHistory.html");
            dispatcher.forward(request, response);
            out.println("Welcome "+username);
            
          
            
        } 
         
         else if(username.equals("student")&& password.equals("student123")){
        
         HttpSession session = request.getSession();
            session.setAttribute("username", username);
            

      
            RequestDispatcher dispatcher = request.getRequestDispatcher("Studentportal.html");
            dispatcher.forward(request, response);
            out.println("Welcome "+username);
        
        }
         
         
         else {
          
            JOptionPane.showMessageDialog(new JFrame(), "Wrong username or password!");
            RequestDispatcher ds = request.getRequestDispatcher("index.html");
            ds.include(request, response);
        }
          Cookie kc=new Cookie("uname", username);
           response.addCookie(kc);
    }
       catch(Exception e){
        e.printStackTrace();
        }
    }
       
}
